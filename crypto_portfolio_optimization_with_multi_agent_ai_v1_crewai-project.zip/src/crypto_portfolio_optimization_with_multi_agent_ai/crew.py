import os
from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	ScrapeWebsiteTool
)



@CrewBase
class CryptoPortfolioOptimizationWithMultiAgentAiCrew:
    """CryptoPortfolioOptimizationWithMultiAgentAi crew"""

    
    @agent
    def crypto_data_manager(self) -> Agent:
        
        return Agent(
            config=self.agents_config["crypto_data_manager"],
            tools=[ScrapeWebsiteTool()],
            reasoning=False,
            inject_date=True,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
        )
    
    @agent
    def static_portfolio_optimizer(self) -> Agent:
        
        return Agent(
            config=self.agents_config["static_portfolio_optimizer"],
            tools=[],
            reasoning=False,
            inject_date=True,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
        )
    
    @agent
    def rolling_portfolio_optimizer(self) -> Agent:
        
        return Agent(
            config=self.agents_config["rolling_portfolio_optimizer"],
            tools=[],
            reasoning=False,
            inject_date=True,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
        )
    
    @agent
    def portfolio_performance_analyst(self) -> Agent:
        
        return Agent(
            config=self.agents_config["portfolio_performance_analyst"],
            tools=[],
            reasoning=False,
            inject_date=True,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
        )
    
    @agent
    def benchmark_comparison_analyst(self) -> Agent:
        
        return Agent(
            config=self.agents_config["benchmark_comparison_analyst"],
            tools=[],
            reasoning=False,
            inject_date=True,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
        )
    
    @agent
    def portfolio_strategy_reporter(self) -> Agent:
        
        return Agent(
            config=self.agents_config["portfolio_strategy_reporter"],
            tools=[],
            reasoning=False,
            inject_date=True,
            llm=LLM(
                model="gpt-4o-mini",
                temperature=0.7,
            ),
        )
    

    
    @task
    def load_and_prepare_crypto_data(self) -> Task:
        return Task(
            config=self.tasks_config["load_and_prepare_crypto_data"],
        )
    
    @task
    def static_portfolio_optimization(self) -> Task:
        return Task(
            config=self.tasks_config["static_portfolio_optimization"],
        )
    
    @task
    def rolling_window_portfolio_optimization(self) -> Task:
        return Task(
            config=self.tasks_config["rolling_window_portfolio_optimization"],
        )
    
    @task
    def portfolio_performance_analysis(self) -> Task:
        return Task(
            config=self.tasks_config["portfolio_performance_analysis"],
        )
    
    @task
    def benchmark_performance_comparison(self) -> Task:
        return Task(
            config=self.tasks_config["benchmark_performance_comparison"],
        )
    
    @task
    def comprehensive_strategy_report(self) -> Task:
        return Task(
            config=self.tasks_config["comprehensive_strategy_report"],
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the CryptoPortfolioOptimizationWithMultiAgentAi crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )
